const vendors = [
    "Siemens",
    "Schneider",
    "ABB",
    "Honeywell",
    "Cisco",
    "Rockwell",
    "Mitsubishi",
    "Omron"
];

const models = [
    "S7-1200",
    "S7-1500",
    "ControlLogix",
    "Magelis",
    "NX102",
    "CompactLogix",
    "PLC-500"
];

const deviceTypes = [
    "PLC",
    "HMI",
    "RTU",
    "Switch",
    "Firewall",
    "Historian",
    "Gateway",
    "Sensor"
];

const sites = [
    "Plant-A",
    "Plant-B",
    "Plant-C",
    "Factory-1",
    "Factory-2",
    "Substation-1",
    "Warehouse-1"
];

class AssetGenerator {

    random(array) {
        return array[
            Math.floor(Math.random() * array.length)
        ];
    }

    randomIp(index) {

        return `192.168.${Math.floor(index / 255)}.${index % 255}`;

    }

    randomMac(index) {

        const value = index
            .toString(16)
            .padStart(6, "0");

        return `AA:BB:${value.substring(0,2)}:${value.substring(2,4)}:${value.substring(4,6)}:CC`;

    }

    generate(count = 10000) {

        const assets = [];

        for (let i = 1; i <= count; i++) {

            assets.push({

                id: `ASSET-${i}`,

                name: `Device-${i}`,

                ipAddress:
                    this.randomIp(i),

                macAddress:
                    this.randomMac(i),

                vendor:
                    this.random(vendors),

                model:
                    this.random(models),

                deviceType:
                    this.random(deviceTypes),

                siteName:
                    this.random(sites),

                updatedAt:
                    new Date(
                        Date.now() -
                        Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000
                    ).toISOString()

            });

        }

        return assets;

    }

}

module.exports =
    new AssetGenerator();
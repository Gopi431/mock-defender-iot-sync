const express = require("express");

const router = express.Router();

const oauthController =
    require("../controllers/oauth.controller");

router.post(
    "/oauth/token",
    oauthController.getToken
);

module.exports = router;
const express = require("express");

const router = express.Router();

const controller =
    require("../controllers/assets.controller");

router.get(
    "/assets",
    controller.getAssets
);

module.exports = router;
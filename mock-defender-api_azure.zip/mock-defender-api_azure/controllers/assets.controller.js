const assetsService =
    require("../services/assets.service");

class AssetsController {

    async getAssets(req, res) {

        try {
    
            const auth =
                req.headers.authorization;
    
            if (
                !auth ||
                auth !==
                "Bearer mock-access-token"
            ) {
    
                return res.status(401).json({
    
                    message: "Unauthorized"
    
                });
    
            }
    
            const response =
                await assetsService.getAssets(req);
    
            return res.json(response);
    
        } catch (error) {
    
            return res.status(
                error.status || 500
            ).json({
    
                message:
                    error.message
    
            });
    
        }
    
    }

}

module.exports =
    new AssetsController();
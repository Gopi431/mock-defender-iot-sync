const oauthService =
    require("../services/oauth.service");

class OAuthController {

    async getToken(req, res) {

        try {

            const response =
                await oauthService.getToken(req.body);

            return res.status(200).json(response);

        } catch (error) {

            return res.status(401).json({
                message: error.message
            });

        }

    }

}

module.exports =
    new OAuthController();
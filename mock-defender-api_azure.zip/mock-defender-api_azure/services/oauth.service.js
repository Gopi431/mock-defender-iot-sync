class OAuthService {

    async getToken(body) {

        const {

            client_id,
            client_secret,
            grant_type

        } = body;

        if (
            client_id !== "test-client" ||
            client_secret !== "test-secret"
        ) {

            throw new Error(
                "Invalid Client Credentials"
            );

        }

        if (
            grant_type !==
            "client_credentials"
        ) {

            throw new Error(
                "Unsupported Grant Type"
            );

        }

        return {

            token_type: "Bearer",

            access_token:
                "mock-access-token",

            expires_in: 3600

        };

    }

}

module.exports =
    new OAuthService();
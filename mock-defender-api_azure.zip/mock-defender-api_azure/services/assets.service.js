const assetGenerator = require("../utils/assetGenerator");

class AssetsService {

    constructor() {

        /**
         * Generate mock assets once when server starts.
         */
        this.assets =
            assetGenerator.generate(100);

    }

    /**
     * Simulate random API delay
     */
    async delay() {

        const time =
            Math.floor(Math.random() * 500);

        return new Promise(resolve => {

            setTimeout(resolve, time);

        });

    }

    /**
     * Randomly throw 429
     */
    simulate429() {

        const random =
            Math.floor(Math.random() * 100);

        if (random < 5) {

            const error =
                new Error("Too Many Requests");

            error.status = 429;

            throw error;

        }

    }

    /**
     * Randomly throw 500
     */
    simulate500() {

        const random =
            Math.floor(Math.random() * 100);

        if (random < 3) {

            const error =
                new Error("Internal Server Error");

            error.status = 500;

            throw error;

        }

    }

    /**
     * GET /api/assets
     */
    async getAssets(req) {

        await this.delay();

        this.simulate429();

        this.simulate500();

        const page =
            Number(req.query.page || 1);

        const limit =
            Number(req.query.limit || 100);

        const updatedAfter =
            req.query.updatedAfter;

        let assets =
            [...this.assets];

        /**
         * Incremental Sync
         */
        if (updatedAfter) {

            assets =
                assets.filter(asset => {

                    return (
                        new Date(asset.updatedAt) >
                        new Date(updatedAfter)
                    );

                });

        }

        /**
         * Pagination
         */
        const start =
            (page - 1) * limit;

        const end =
            start + limit;

        const result =
            assets.slice(start, end);

        /**
         * Microsoft style nextLink
         */
        let nextLink = null;

        if (end < assets.length) {

            nextLink =
                `/assets?page=${page + 1}&limit=${limit}`;

            if (updatedAfter) {

                nextLink +=
                    `&updatedAfter=${encodeURIComponent(updatedAfter)}`;

            }

        }

        return {

            "@odata.count":
                assets.length,

            value:
                result,

            "@odata.nextLink":
                nextLink

        };

    }

}

module.exports =
    new AssetsService();
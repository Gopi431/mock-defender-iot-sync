const express = require("express");

const assetsRoutes =
    require("./routes/assets.routes");

const oauthRoutes =
    require("./routes/oauth.routes");

const app = express();

app.use(express.json());

app.use("/api", assetsRoutes);

app.use("/", oauthRoutes);

app.listen(3000, () => {

    console.log(
        "Mock Defender API Running on Port 3000"
    );

});
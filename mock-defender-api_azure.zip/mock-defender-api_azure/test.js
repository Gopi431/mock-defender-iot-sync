const generator =
require("./utils/assetGenerator");

const assets =
generator.generate(5);

console.log(assets);
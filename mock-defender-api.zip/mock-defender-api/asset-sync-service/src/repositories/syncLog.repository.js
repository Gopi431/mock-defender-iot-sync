const { SyncLog } = require("../models");

class SyncLogRepository {

    async create(log, transaction = null) {

        return SyncLog.create(
            log,
            {
                transaction
            }
        );

    }

    async update(
        id,
        payload,
        transaction = null
    ) {

        return SyncLog.update(

            payload,

            {
                where: {
                    id
                },

                transaction
            }

        );

    }

}

module.exports =
    new SyncLogRepository();
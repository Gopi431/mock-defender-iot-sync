const { SyncMetadata } = require("../models");

class SyncMetadataRepository {

    async getLastSyncTime(syncName) {

        const record =
            await SyncMetadata.findOne({

                where: {
                    syncName
                }

            });

        return record;

    }

    async updateLastSyncTime(
        syncName,
        timestamp,
        transaction = null
    ) {

        return SyncMetadata.update(

            {
                lastSyncTime: timestamp
            },

            {
                where: {
                    syncName
                },

                transaction
            }

        );

    }

}

module.exports =
    new SyncMetadataRepository();
const { Asset } = require("../models");

class AssetRepository {

    async bulkUpsert(assets, transaction = null) {

        if (!assets.length) {
            return;
        }

        return Asset.bulkCreate(
            assets,
            {
                transaction,

                updateOnDuplicate: [
                    "assetName",
                    "ipAddress",
                    "macAddress",
                    "vendor",
                    "model",
                    "deviceType",
                    "siteName",
                    "rawPayload",
                    "defenderUpdatedAt",
                    "updatedAt"
                ]
            }
        );
    }

    async findByAssetId(assetId) {

        return Asset.findOne({
            where: {
                assetId
            }
        });

    }

    async countAssets() {

        return Asset.count();

    }

}

module.exports = new AssetRepository();
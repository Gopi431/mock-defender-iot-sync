const assetService = require("../services/asset.service");
const logger = require("../utils/logger");

class SyncController {

    /**
     * POST /api/sync
     */
    async sync(req, res, next) {

        try {

            logger.info("Manual Asset Sync Requested");

            const result =
                await assetService.syncAssets();

            return res.status(200).json({

                success: true,

                message:
                    "Asset Sync Completed Successfully",

                data: result

            });

        } catch (error) {

            logger.error(error.message);

            next(error);

        }

    }

}

module.exports =
    new SyncController();
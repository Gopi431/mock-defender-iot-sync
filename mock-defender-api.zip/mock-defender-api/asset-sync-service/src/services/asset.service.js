const sequelize = require("../config/database");

const authService = require("./auth.service");
const defenderClient = require("../clients/defender.client");

const assetRepository = require("../repositories/asset.repository");
const syncMetadataRepository = require("../repositories/syncMetadata.repository");
const syncLogRepository = require("../repositories/syncLog.repository");

const { chunkArray } = require("../utils/chunk.util");
const logger = require("../utils/logger");

class AssetService {

    async syncAssets() {

        logger.info("========================================");
        logger.info("Starting Asset Synchronization");
        logger.info("========================================");

        const syncName = process.env.SYNC_NAME;

        const metadata =
            await syncMetadataRepository.getLastSyncTime(syncName);

        const lastSyncTime =
            metadata?.lastSyncTime || null;

        logger.info(`Last Sync Time : ${lastSyncTime}`);

        const syncLog =
            await syncLogRepository.create({
                syncName,
                startedAt: new Date(),
                status: "IN_PROGRESS",
                totalRecords: 0,
                successRecords: 0,
                failedRecords: 0
            });

        let totalRecords = 0;
        let successRecords = 0;
        let failedRecords = 0;

        try {

            /**
             * Get OAuth Token
             */
            const accessToken =
                await authService.getAccessToken();

            /**
             * Read Defender Pages
             */
            for await (const assets of defenderClient.getAssetPages(lastSyncTime)) {

                if (!assets.length) {
                    continue;
                }

                totalRecords += assets.length;

                const transformed =
                    this.transformAssets(assets);

                await this.saveAssets(transformed);

                successRecords += transformed.length;

                logger.info(
                    `Saved ${transformed.length} assets`
                );

            }

            await syncMetadataRepository.updateLastSyncTime(
                syncName,
                new Date()
            );

            await syncLogRepository.update(
                syncLog.id,
                {
                    completedAt: new Date(),
                    status: "SUCCESS",
                    totalRecords,
                    successRecords,
                    failedRecords
                }
            );

            logger.info("Asset Sync Completed Successfully");

            return {
                totalRecords,
                successRecords,
                failedRecords
            };

        } catch (error) {

            logger.error(error);

            failedRecords =
                totalRecords - successRecords;

            await syncLogRepository.update(
                syncLog.id,
                {
                    completedAt: new Date(),
                    status: "FAILED",
                    totalRecords,
                    successRecords,
                    failedRecords,
                    errorMessage: error.message
                }
            );

            throw error;

        }

    }

    transformAssets(assets) {

        return assets.map(asset => ({

            assetId: asset.id,

            assetName: asset.name,

            ipAddress: asset.ipAddress,

            macAddress: asset.macAddress,

            vendor: asset.vendor,

            model: asset.model,

            deviceType: asset.deviceType,

            siteName: asset.siteName,

            defenderUpdatedAt: asset.updatedAt,

            rawPayload: asset

        }));

    }

    async saveAssets(records) {

        if (!records.length) {
            return;
        }

        const transaction =
            await sequelize.transaction();

        try {

            const batchSize =
                Number(process.env.BATCH_SIZE) || 500;

            const batches =
                chunkArray(records, batchSize);

            for (const batch of batches) {

                await assetRepository.bulkUpsert(
                    batch,
                    transaction
                );

            }

            await transaction.commit();

        } catch (error) {

            await transaction.rollback();

            throw error;

        }

    }

}

module.exports = new AssetService();
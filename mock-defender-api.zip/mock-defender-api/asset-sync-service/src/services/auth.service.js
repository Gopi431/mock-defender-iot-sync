const axios = require("axios");
const logger = require("../utils/logger");

class AuthService {

    constructor() {
        this.accessToken = null;
        this.expiresAt = null;
    }

    /**
     * Returns cached token if still valid,
     * otherwise generates a new token.
     */
    async getAccessToken() {

        if (this.isTokenValid()) {
            logger.info("Using cached access token.");
            return this.accessToken;
        }

        return this.generateAccessToken();
    }

    /**
     * Check whether current token is still valid.
     * Refresh 5 minutes before expiry.
     */
    isTokenValid() {

        if (!this.accessToken || !this.expiresAt) {
            return false;
        }

        const fiveMinutes = 5 * 60 * 1000;

        return (
            this.expiresAt.getTime() - Date.now()
        ) > fiveMinutes;
    }

    /**
     * Generate OAuth token.
     *
     * Replace this implementation with the
     * Microsoft Azure OAuth API when connecting
     * to the real Defender for IoT service.
     */
    async generateAccessToken() {

        try {

            logger.info("Generating new access token.");

            /**
             * -------------------------------------------------------
             * MOCK TOKEN
             * -------------------------------------------------------
             *
             * Replace below with:
             *
             * POST
             * https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token
             *
             */

            const token = "mock-access-token";

            this.accessToken = token;

            this.expiresAt =
                new Date(
                    Date.now() + (60 * 60 * 1000)
                );

            logger.info("Access token generated.");

            return token;

        } catch (error) {

            logger.error(
                `Unable to generate token : ${error.message}`
            );

            throw error;
        }

    }

    /**
     * Force refresh token.
     */
    async refreshToken() {

        this.accessToken = null;
        this.expiresAt = null;

        return this.generateAccessToken();

    }

}

module.exports = new AuthService();
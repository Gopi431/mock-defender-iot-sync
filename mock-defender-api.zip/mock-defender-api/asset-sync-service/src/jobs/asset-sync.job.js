const cron = require("node-cron");

const assetService = require("../services/asset.service");

const logger = require("../utils/logger");

let isSyncRunning = false;

class AssetSyncJob {

    start() {

        cron.schedule(
            "*/15 * * * *",
            async () => {

                if (isSyncRunning) {

                    logger.warn(
                        "Asset Sync already running. Skipping current schedule."
                    );

                    return;

                }

                isSyncRunning = true;

                logger.info(
                    "================================================="
                );

                logger.info(
                    "Microsoft Defender IoT Asset Sync Started"
                );

                logger.info(
                    "================================================="
                );

                try {

                    const result =
                        await assetService.syncAssets();

                    logger.info(
                        `Total Records : ${result.totalRecords}`
                    );

                    logger.info(
                        `Success Records : ${result.successRecords}`
                    );

                    logger.info(
                        "Microsoft Defender IoT Asset Sync Completed Successfully"
                    );

                } catch (error) {

                    logger.error(
                        "Asset Sync Failed"
                    );

                    logger.error(
                        error.message
                    );

                } finally {

                    isSyncRunning = false;

                    logger.info(
                        "================================================="
                    );

                }

            },
            {
                scheduled: true,
                timezone: "Asia/Kolkata"
            }
        );

        logger.info(
            "Asset Sync Scheduler Started."
        );

    }

}

module.exports = new AssetSyncJob();
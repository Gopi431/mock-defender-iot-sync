const axios = require("axios");

const authService = require("../services/auth.service");
const logger = require("../utils/logger");

const axiosInstance = axios.create({
    baseURL: process.env.DEFENDER_BASE_URL,
    timeout: 30000,
    headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
    }
});

/**
 * -------------------------------------------------------
 * Request Interceptor
 * -------------------------------------------------------
 */
axiosInstance.interceptors.request.use(

    async (config) => {

        try {

            const token =
                await authService.getAccessToken();

            config.headers.Authorization =
                `Bearer ${token}`;

            logger.info(
                `[REQUEST] ${config.method.toUpperCase()} ${config.baseURL}${config.url}`
            );

            return config;

        } catch (error) {

            logger.error(
                `Request Interceptor Error : ${error.message}`
            );

            return Promise.reject(error);

        }

    },

    (error) => {

        logger.error(
            `Axios Request Error : ${error.message}`
        );

        return Promise.reject(error);

    }

);

/**
 * -------------------------------------------------------
 * Response Interceptor
 * -------------------------------------------------------
 */
axiosInstance.interceptors.response.use(

    (response) => {

        logger.info(
            `[RESPONSE] ${response.status} ${response.config.url}`
        );

        return response;

    },

    async (error) => {

        const status =
            error.response?.status;

        logger.error(
            `[RESPONSE ERROR] ${status || "UNKNOWN"} ${error.message}`
        );

        /**
         * If token expired
         * Generate new token once
         */

        if (
            status === 401 &&
            !error.config._retry
        ) {

            try {

                error.config._retry = true;

                logger.info(
                    "Refreshing Access Token..."
                );

                const token =
                    await authService.refreshToken();

                error.config.headers.Authorization =
                    `Bearer ${token}`;

                return axiosInstance(
                    error.config
                );

            } catch (refreshError) {

                logger.error(
                    refreshError.message
                );

                return Promise.reject(
                    refreshError
                );

            }

        }

        return Promise.reject(error);

    }

);

module.exports = axiosInstance;
const getNextPage = (
    response
) => {

    return (
        response.nextLink ||
        response["@odata.nextLink"] ||
        response.nextPage ||
        null
    );

};

module.exports = {
    getNextPage
};
const DEFAULT_RETRIES =
    Number(process.env.MAX_RETRIES || 5);

const delay = (ms) =>
    new Promise(resolve => setTimeout(resolve, ms));

const shouldRetry = (error) => {

    const status =
        error?.response?.status;

    return (
        status === 429 ||
        status === 500 ||
        status === 502 ||
        status === 503 ||
        status === 504 ||
        error.code === "ECONNRESET" ||
        error.code === "ETIMEDOUT"
    );

};

const retryWithBackoff = async (
    operation,
    retries = DEFAULT_RETRIES
) => {

    let attempt = 0;

    while (attempt <= retries) {

        try {

            return await operation();

        } catch (error) {

            if (
                !shouldRetry(error) ||
                attempt === retries
            ) {

                throw error;

            }

            attempt++;

            const waitTime =
                Math.pow(2, attempt) * 1000;

            console.log(
                `Retry ${attempt}/${retries} after ${waitTime} ms`
            );

            await delay(waitTime);

        }

    }

};

module.exports = {
    retryWithBackoff
};
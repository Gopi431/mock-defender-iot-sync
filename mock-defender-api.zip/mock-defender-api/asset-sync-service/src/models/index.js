const sequelize = require("../config/database");

const Asset = require("./asset.model");
const SyncMetadata = require("./syncMetadata.model");
const SyncLog = require("./syncLog.model");

/*
 No associations are required for this project.

 Assets, SyncMetadata and SyncLog are independent tables.
*/

module.exports = {
  sequelize,
  Asset,
  SyncMetadata,
  SyncLog
};
const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const SyncMetadata = sequelize.define(
  "SyncMetadata",
  {
    id: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },

    syncName: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      field: "sync_name"
    },

    lastSyncTime: {
      type: DataTypes.DATE,
      field: "last_sync_time"
    }
  },
  {
    tableName: "sync_metadata",

    underscored: true,

    timestamps: true
  }
);

module.exports = SyncMetadata;
const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const SyncLog = sequelize.define(
  "SyncLog",
  {
    id: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },

    syncName: {
      type: DataTypes.STRING,
      field: "sync_name"
    },

    startedAt: {
      type: DataTypes.DATE,
      field: "started_at"
    },

    completedAt: {
      type: DataTypes.DATE,
      field: "completed_at"
    },

    status: {
      type: DataTypes.STRING
    },

    totalRecords: {
      type: DataTypes.INTEGER,
      field: "total_records"
    },

    successRecords: {
      type: DataTypes.INTEGER,
      field: "success_records"
    },

    failedRecords: {
      type: DataTypes.INTEGER,
      field: "failed_records"
    },

    errorMessage: {
      type: DataTypes.TEXT,
      field: "error_message"
    }
  },
  {
    tableName: "sync_logs",

    underscored: true,

    timestamps: true
  }
);

module.exports = SyncLog;
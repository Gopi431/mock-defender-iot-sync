const { DataTypes } = require("sequelize");

const sequelize = require("../config/database");

const Asset = sequelize.define(
    "Asset",
    {
        id: {
            type: DataTypes.BIGINT,
            primaryKey: true,
            autoIncrement: true
        },

        assetId: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            field: "asset_id"
        },

        assetName: {
            type: DataTypes.STRING,
            allowNull: false,
            field: "asset_name"
        },

        ipAddress: {
            type: DataTypes.STRING,
            field: "ip_address"
        },

        macAddress: {
            type: DataTypes.STRING,
            field: "mac_address"
        },

        vendor: {
            type: DataTypes.STRING
        },

        model: {
            type: DataTypes.STRING
        },

        deviceType: {
            type: DataTypes.STRING,
            field: "device_type"
        },

        siteName: {
            type: DataTypes.STRING,
            field: "site_name"
        },

        defenderUpdatedAt: {
            type: DataTypes.DATE,
            field: "defender_updated_at"
        },

        rawPayload: {
            type: DataTypes.JSONB,
            field: "raw_payload"
        }
    },
    {
        tableName: "assets",

        timestamps: true,

        underscored: true
    }
);

module.exports = Asset;
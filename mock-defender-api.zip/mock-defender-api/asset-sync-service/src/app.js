const path = require("path");

require("dotenv").config({
    path: path.join(__dirname, "../.env")
});

const express = require("express");

const sequelize =
    require("./config/database");

const assetSyncJob =
    require("./jobs/asset-sync.job");

const logger =
    require("./utils/logger");

const syncRoutes =
    require("./routes/sync.routes");

const errorHandler =
    require("./middleware/errorHandler");

console.log("Working Directory:", process.cwd());

console.log("DB_HOST =", process.env.DB_HOST);
console.log("DB_NAME =", process.env.DB_NAME);
console.log("DB_USER =", process.env.DB_USER);
console.log("DB_PASSWORD =", process.env.DB_PASSWORD);

const app = express();

app.use(express.json());

app.use(express.urlencoded({
    extended: true
}));

/**
 * Health Check
 */
app.get("/health", (req, res) => {

    res.status(200).json({
        success: true,
        message: "Mock Defender API Running"
    });

});

app.use("/api", syncRoutes);

/**
 * 404
 */
app.use((req, res) => {

    res.status(404).json({
        success: false,
        message: "Route Not Found"
    });

});

app.use(errorHandler);

const PORT =
    process.env.PORT || 3001;

(async () => {

    try {

        await sequelize.authenticate();

        logger.info(
            "Database Connected Successfully"
        );

        assetSyncJob.start();

        app.listen(
            PORT,
            () => {

                logger.info(
                    `Application Started on Port ${PORT}`
                );

            }
        );

    } catch (error) {

        logger.error(
            error.message
        );

        process.exit(1);

    }

})();

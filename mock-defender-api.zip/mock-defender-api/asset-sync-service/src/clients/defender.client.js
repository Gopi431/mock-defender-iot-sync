const axios = require("../config/axios");

const {
    retryWithBackoff
} = require("../utils/retry.util");

const logger =
    require("../utils/logger");

class DefenderClient {

    /**
     * Build Initial URL
     */
    buildAssetUrl(lastSyncTime) {

        const pageSize =
            process.env.PAGE_SIZE || 1;

        let url =
            `/assets?page=1&limit=${pageSize}`;

        if (lastSyncTime) {

            url +=
                `&updatedAfter=${encodeURIComponent(lastSyncTime)}`;

        }

        return url;

    }

    /**
     * Fetch One Page
     */
    async fetchPage(url) {

        return retryWithBackoff(

            async () => {

                logger.info(
                    `Fetching Assets : ${url}`
                );

                const response =
                    await axios.get(url);

                return response.data;

            }

        );

    }

    /**
     * Async Generator
     *
     * Returns ONE PAGE at a time.
     *
     * for await (const assets of defenderClient.getAssetPages(...))
     *
     */
    async *getAssetPages(lastSyncTime) {

        let nextUrl =
            this.buildAssetUrl(lastSyncTime);

        while (nextUrl) {

            const response =
                await this.fetchPage(
                    nextUrl
                );

            const assets =
                response.value || [];

            logger.info(
                `Received ${assets.length} assets`
            );

            yield assets;

            nextUrl =
                this.getNextPage(
                    response
                );

        }

    }

    /**
     * Pagination Support
     */
    getNextPage(response) {

        if (
            response.nextLink
        ) {

            return response.nextLink;

        }

        if (
            response["@odata.nextLink"]
        ) {

            return response["@odata.nextLink"];

        }

        if (
            response.nextPage
        ) {

            const page =
                response.nextPage;

            const limit =
                process.env.PAGE_SIZE;

            return `/assets?page=${page}&limit=${limit}`;

        }

        return null;

    }

}

module.exports =
    new DefenderClient();
const { DataTypes } = require("sequelize");
const sequelize = require("../asset-sync-service/src/config/database");

const Asset = sequelize.define(
  "Asset",
  {
    id: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },

    assetId: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      field: "asset_id"
    },

    assetName: {
      type: DataTypes.STRING,
      field: "asset_name"
    },

    ipAddress: {
      type: DataTypes.STRING,
      field: "ip_address"
    },

    macAddress: {
      type: DataTypes.STRING,
      field: "mac_address"
    },

    vendor: {
      type: DataTypes.STRING
    },

    model: {
      type: DataTypes.STRING
    },

    deviceType: {
      type: DataTypes.STRING,
      field: "device_type"
    },

    siteName: {
      type: DataTypes.STRING,
      field: "site_name"
    },

    rawPayload: {
      type: DataTypes.JSONB,
      field: "raw_payload"
    },

    defenderUpdatedAt: {
      type: DataTypes.DATE,
      field: "defender_updated_at"
    }
  },
  {
    tableName: "assets",

    underscored: true,

    timestamps: true
  }
);

module.exports = Asset;
CREATE TABLE assets (
    id BIGSERIAL PRIMARY KEY,

    asset_id VARCHAR(100) NOT NULL UNIQUE,

    asset_name VARCHAR(255),

    ip_address VARCHAR(100),

    mac_address VARCHAR(100),

    vendor VARCHAR(100),

    model VARCHAR(100),

    device_type VARCHAR(100),

    site_name VARCHAR(100),

    raw_payload JSONB,

    defender_updated_at TIMESTAMP,

    created_at TIMESTAMP DEFAULT NOW(),

    updated_at TIMESTAMP DEFAULT NOW()
);

---------------------------------------------------------

CREATE TABLE sync_metadata (

    id BIGSERIAL PRIMARY KEY,

    sync_name VARCHAR(100) UNIQUE NOT NULL,

    last_sync_time TIMESTAMP,

    created_at TIMESTAMP DEFAULT NOW(),

    updated_at TIMESTAMP DEFAULT NOW()

);

---------------------------------------------------------

INSERT INTO sync_metadata
(
    sync_name,
    last_sync_time
)
VALUES
(
    'asset_sync',
    '1970-01-01 00:00:00'
);

---------------------------------------------------------

CREATE TABLE sync_logs (

    id BIGSERIAL PRIMARY KEY,

    sync_name VARCHAR(100),

    started_at TIMESTAMP,

    completed_at TIMESTAMP,

    status VARCHAR(30),

    total_records INTEGER,

    success_records INTEGER,

    failed_records INTEGER,

    error_message TEXT,

    created_at TIMESTAMP DEFAULT NOW()

);